﻿# Per-widget collection and explanation (decision David 2026-10-14, points 6, 73 and 74). Every widget names the source
# of its figure, what refreshing that widget alone collects for the population of its board (the selected
# workstation, or the active workstations of the OU shown on Accueil, never the whole domain), what pausing it
# changes, and how its figure is computed. Pure rules: no WPF, no network, no disk.

# key|source|formula|criteria|exclusions. Sources: Directory (OU read into the local base), Presence (ping), Console
# (console user read by WMI), Inventory (light WMI reading), BitLocker (presence of the recovery objects of the OU),
# Local (computed from data already stored), ComputerQuick / ComputerDeep (inventory of the selected workstation),
# Card (attributes reread with the object card), Software (software list of the workstation).
$script:DomeniaWidgetSourceText = @'
fleet.health|Local|Score = postes évalués sans point détecté ÷ postes évalués × 100.|Règles de santé activées et seuils de la politique applicable à chaque OU.|Comptes désactivés ; postes incomplets (donnée nécessaire absente ou expirée) retirés du dénominateur et jamais comptés sains ; score retenu sous 50 % de couverture.
fleet.attention|Local|Contrôles en défaut, du plus grave au moins grave ; chaque point compte ses postes une fois.|Règles de santé activées.|Règles désactivées ou suspendues ; comptes désactivés.
fleet.machines|Directory|Nombre de comptes ordinateur du périmètre.|Tous les comptes de la base locale : activés, désactivés et état inconnu.|Aucune.
fleet.enabled|Directory|Nombre de comptes ordinateur activés.|userAccountControl sans le drapeau de désactivation.|Comptes désactivés ou à lʼétat inconnu ; ce nombre ne décrit pas la présence réseau.
fleet.accountunknown|Directory|Nombre de comptes dont lʼétat nʼest pas lu.|userAccountControl absent de la copie locale.|Comptes activés et désactivés.
fleet.accountstatus|Directory|Répartition des comptes : activés, désactivés, état inconnu.|userAccountControl de la copie locale.|Aucune.
fleet.stale|Directory|Comptes activés dont la dernière connexion AD dépasse le seuil dʼinactivité.|lastLogonTimestamp répliqué, précis à 14 jours près ; seuil de la politique.|Comptes désactivés ; dates inconnues comptées à part.
fleet.disabled|Directory|Nombre de comptes ordinateur désactivés encore dans le périmètre.|userAccountControl avec le drapeau de désactivation.|Comptes activés ou à lʼétat inconnu.
fleet.created|Directory|Comptes activés créés ces 30 derniers jours.|Attribut whenCreated lu avec la base.|Comptes désactivés ; attribut non lu.
fleet.pwdold|Directory|Comptes activés dont le mot de passe machine dépasse le seuil.|Attribut pwdLastSet ; seuil de la politique.|Comptes désactivés ; attribut non lu.
fleet.servers|Directory|Répartition des comptes activés entre serveurs et postes de travail.|Attribut operatingSystem et famille de la table des fins de service.|Comptes désactivés.
fleet.laps|Directory|Comptes activés sans expiration LAPS visible.|Attributs dʼexpiration LAPS lus avec la base, jamais le mot de passe.|Comptes désactivés ; rien nʼest compté tant quʼaucune expiration nʼest visible avec ce compte.
fleet.bitlocker|BitLocker|Comptes activés sans clé de récupération BitLocker visible.|Objets de récupération de lʼOU lus sur demande : nom, emplacement et date, jamais la clé.|Comptes désactivés ; rien nʼest compté tant quʼaucune clé nʼest visible avec ce compte.
fleet.versions|Directory|Répartition des comptes activés par version de Windows.|Attributs operatingSystem et operatingSystemVersion.|Comptes désactivés.
fleet.eos|Directory|Comptes activés dont la version nʼest plus maintenue.|Build AD comparé à la table des fins de service livrée.|Comptes désactivés ; version non lue.
fleet.win10|Directory|Comptes activés sous Windows 10.|Attribut operatingSystem et build.|Éditions LTSC, LTSB et IoT ; comptes désactivés.
fleet.os|Directory|Répartition des comptes activés par système dʼexploitation.|Attribut operatingSystem.|Comptes désactivés.
fleet.lastlogon|Directory|Répartition des comptes activés par ancienneté de la dernière connexion au domaine.|lastLogonTimestamp répliqué, précis à 14 jours près.|Comptes désactivés.
fleet.ou|Directory|Comptes activés par OU ou sous-OU.|OU parente de chaque compte.|Comptes désactivés.
fleet.presence|Presence|Répartition des comptes activés par dernier résultat de ping.|Ping daté par le poste qui lʼa mesuré, conservé selon la durée de conservation.|Comptes désactivés ; ping expiré compté Non vérifié, jamais éteint.
fleet.users|Console|Utilisateurs distincts vus en session console.|Lecture WMI de la console, datée et conservée selon la durée de conservation.|Sessions RDP ; lectures expirées.
fleet.lastcheck|Presence|Date du ping le plus récent du périmètre.|Pings datés des comptes activés.|Pings expirés.
fleet.wmi|Inventory|Postes dont la dernière lecture WMI est datée, indépendante du ping.|Relevé WMI léger daté de lʼobservation, conservé selon la durée de conservation.|Postes sans réponse WMI utilisable (non lu, en erreur ou expiré) ; comptes désactivés.
fleet.reach|Presence|Répartition des comptes activés selon la combinaison du ping et de la réponse WMI.|Ping daté et lecture WMI datée de lʼobservation ; une absence de réponse ne prouve pas que le poste est éteint.|Postes sans ping ni réponse WMI exploitables ; comptes désactivés.
fleet.models|Inventory|Répartition des postes analysés par modèle.|Relevé WMI léger (Win32_ComputerSystem) daté.|Postes sans relevé exploitable ; relevés expirés.
fleet.releases|Inventory|Répartition des postes analysés par version relevée.|Build lu par WMI (Win32_OperatingSystem).|Postes sans relevé exploitable ; relevés expirés.
fleet.ram|Inventory|Postes analysés par quantité de mémoire installée.|TotalPhysicalMemory lu par WMI.|Postes sans relevé exploitable ; relevés expirés.
fleet.diskfree|Inventory|Postes analysés par espace libre du disque C:.|Win32_LogicalDisk C: ; seuils de la politique.|Postes sans taille de disque lue ; relevés expirés.
fleet.lowdisk|Inventory|Postes analysés dont C: est sous le seuil critique dʼespace libre.|Win32_LogicalDisk C: ; seuil de la politique.|Postes sans taille de disque lue ; relevés expirés.
fleet.uptime|Inventory|Postes analysés non redémarrés depuis plus de 30 jours.|LastBootUpTime lu par WMI.|Postes sans date de démarrage lue ; relevés expirés.
fleet.trend|Local|Nombre de postes à traiter, un point par instantané quotidien.|Instantanés locaux de lʼOU affichée.|Jours sans instantané ; les postes de chaque jour ne sont pas conservés.
fleet.trend.win10|Local|Postes sous Windows 10 hors LTSC, LTSB et IoT, un point par instantané quotidien.|Instantanés locaux de lʼOU affichée.|Jours sans instantané ; les postes de chaque jour ne sont pas conservés.
fleet.trend.stale|Local|Postes sans connexion depuis le seuil dʼinactivité, un point par instantané quotidien.|Instantanés locaux de lʼOU affichée.|Jours sans instantané ; les postes de chaque jour ne sont pas conservés.
fleet.trend.lowdisk|Local|Postes analysés avec C: presque plein, un point par instantané quotidien.|Instantanés locaux de lʼOU affichée.|Jours sans instantané ; les postes de chaque jour ne sont pas conservés.
computer.health|Local|Score = 100 − 25 par point critique − 10 par point à surveiller, minimum 0.|Contrôles activés dans les règles de santé du poste.|Contrôles non lus : le score est retenu et lʼévaluation déclarée incomplète.
computer.attention|Local|Contrôles en défaut du poste, du plus grave au moins grave.|Contrôles activés dans les règles de santé du poste.|Contrôles désactivés ou suspendus.
computer.identity|ComputerQuick|Fiche des valeurs lues par lʼinventaire : système, modèle, processeur, mémoire, durée de fonctionnement, utilisateur en console, adresse IP et domaine.|Mêmes lectures que les widgets de chaque ligne : Win32_OperatingSystem, Win32_ComputerSystem, Win32_Processor, Win32_PhysicalMemory et Win32_NetworkAdapterConfiguration.|Lignes que lʼinventaire nʼa pas renvoyées : absentes de la fiche.
computer.adaccount|Card|Fiche du compte ordinateur : état, OU, âge du mot de passe machine, dernière connexion au domaine, expiration LAPS, responsable et écart dʼhorloge.|Attributs lus avec la fiche du poste (userAccountControl, whenCreated, pwdLastSet, lastLogonTimestamp, expiration LAPS, managedBy) ; horloge mesurée par le dernier inventaire.|Attributs absents ou non visibles avec ce compte ; jamais le mot de passe LAPS.
computer.status|ComputerQuick|Une ligne par contrôle : BitLocker du volume système, Secure Boot, pare-feu par profil, antivirus déclaré, redémarrage en attente et ancienneté du dernier correctif.|Mêmes lectures et mêmes seuils que les widgets de chaque contrôle.|Contrôle non lu : ligne « Non lu », jamais comptée comme conforme.
computer.os|ComputerQuick|Version commerciale déduite du build de Windows.|Win32_OperatingSystem et table des fins de service livrée.|Aucune.
computer.model|ComputerQuick|Fabricant, modèle et numéro de série du châssis.|Win32_ComputerSystem et Win32_SystemEnclosure.|Valeurs que le fabricant ne renseigne pas.
computer.cpu|ComputerQuick|Modèle, cœurs et threads du premier processeur.|Win32_Processor.|Aucune.
computer.memory|ComputerQuick|Mémoire physique installée, avec le nombre de barrettes et dʼemplacements.|Win32_PhysicalMemory et emplacements de Win32_PhysicalMemoryArray ; sans barrette exposée, mémoire visible par Windows (Win32_OperatingSystem).|Barrettes non exposées (machines virtuelles) : le total est alors la mémoire visible, annoncée comme telle.
computer.uptime|ComputerQuick|Durée depuis le dernier démarrage, au moment de lʼinventaire.|Win32_OperatingSystem.LastBootUpTime.|Aucune.
computer.user|ComputerQuick|Compte en session console au moment de lʼinventaire.|Win32_ComputerSystem.UserName.|Sessions RDP.
computer.ip|ComputerQuick|Première adresse IPv4 et passerelle de la même carte.|Win32_NetworkAdapterConfiguration.|Cartes sans adresse.
computer.domain|ComputerQuick|Domaine et rôle du poste.|Win32_ComputerSystem.|Aucune.
computer.ad.password|Card|Âge du mot de passe du compte ordinateur.|Attribut pwdLastSet lu avec la fiche.|Aucune.
computer.ad.lastlogon|Card|Ancienneté de la dernière connexion au domaine.|lastLogonTimestamp lu avec la fiche, précis à 14 jours près.|Aucune.
computer.ad.account|Card|Compte activé ou désactivé, et date de création.|userAccountControl et whenCreated lus avec la fiche.|Aucune.
computer.ad.ou|Card|OU qui contient le compte.|DN du compte lu avec la fiche.|Aucune.
computer.ad.laps|Card|Expiration du mot de passe administrateur local.|Attributs dʼexpiration LAPS lus avec la fiche, jamais le mot de passe.|Attribut non visible avec ce compte.
computer.ad.managedby|Card|Responsable déclaré du poste.|Attribut managedBy lu avec la fiche.|Aucune.
computer.ad.clock|ComputerQuick|Écart entre lʼhorloge du poste et la référence disponible.|Heure lue pendant lʼinventaire, comparée au contrôleur ou au poste dʼadministration.|Aucune.
computer.memory.usage|ComputerQuick|Mémoire occupée ÷ mémoire installée, au moment de lʼinventaire.|Win32_OperatingSystem.FreePhysicalMemory ; seuil de la politique.|Aucune.
computer.cpu.load|ComputerQuick|Charge du processeur au moment de lʼinventaire.|Win32_Processor.LoadPercentage.|Aucune.
computer.battery|ComputerQuick|Charge restante de la batterie.|Win32_Battery.EstimatedChargeRemaining ; seuil de la politique.|Postes sans batterie.
computer.disk.system|ComputerQuick|Espace libre ÷ taille du disque système.|Win32_LogicalDisk C: ; seuils de la politique.|Aucune.
computer.disk.volumes|ComputerQuick|Espace libre des autres volumes, en pourcentage.|Win32_LogicalDisk.|Disque système.
computer.services|ComputerQuick|Services en cours, arrêtés et désactivés.|Win32_Service.|Aucune.
computer.processes|ComputerDeep|Part du processeur par processus entre deux lectures espacées de quelques secondes : temps processeur consommé ÷ (intervalle × processeurs logiques), cumulée par nom. Sans mesure sur intervalle, mémoire utilisée par processus.|Win32_Process lu deux fois par lʼinventaire complet, sans ligne de commande ni argument.|Processus démarrés, arrêtés ou dont lʼidentifiant a changé pendant lʼintervalle ; processus inactif du système ; processus au-delà des huit premiers.
computer.events|ComputerDeep|Erreurs du journal Système par source sur 3 jours.|Win32_NTLogEvent, lu par lʼinventaire complet.|Erreurs connues sans gravité.
computer.antivirus|ComputerQuick|Produit antivirus déclaré à Windows.|Centre de sécurité Windows (SecurityCenter2).|Serveurs sans centre de sécurité.
computer.firewall|ComputerQuick|État effectif du pare-feu par profil, et profil appliqué à chaque connexion active.|Registre FirewallPolicy, la stratégie prime sur la clé locale ; catégorie des connexions actives (MSFT_NetConnectionProfile).|Aucune.
computer.bitlocker|ComputerQuick|Protection et chiffrement du volume système : un volume chiffré dont la protection est désactivée est suspendu, pas non chiffré.|Win32_EncryptableVolume (ProtectionStatus et ConversionStatus).|Autres volumes.
computer.secureboot|ComputerQuick|État de Secure Boot écrit par Windows au démarrage, avec le type de micrologiciel.|Registre SecureBoot\State (UEFISecureBootEnabled) et PEFirmwareType.|BIOS hérité ou valeur non exposée : état non mesuré, sans point dʼattention.
computer.updates|ComputerQuick|Build et révision installés, correctif CBS le plus récent et source des mises à jour.|Win32_OperatingSystem, registre CurrentVersion (UBR), Win32_QuickFixEngineering et registre WindowsUpdate.|Aucune conformité nʼest conclue : Win32_QuickFixEngineering ne liste pas toutes les mises à jour.
computer.wsus|ComputerQuick|Serveur WSUS configuré et réellement utilisé par le client de mise à jour.|Registre Policies\WindowsUpdate (WUServer) et valeur UseWUServer de la clé AU.|Adresse WSUS déclarée sans UseWUServer = 1 : non retenue, Windows Update est affiché.
computer.reboot|ComputerQuick|Redémarrage en attente confirmé par une source dʼobligation ; les indices partiels sont montrés sans point dʼattention.|Clés de registre de redémarrage en attente, chacune classée obligation confirmée (CBS, Windows Update, renommage du poste) ou indice partiel.|Indices partiels seuls (renommages de fichiers, paquets CBS, jonction en attente) : jamais comptés comme une obligation.
computer.services.stopped|ComputerQuick|Services automatiques à lʼarrêt.|Win32_Service.|Services démarrés sur déclencheur.
computer.devices|ComputerQuick|Périphériques signalés en erreur.|Win32_PnPEntity.|Aucune.
computer.drivers|ComputerQuick|Pilotes sans signature numérique.|Win32_PnPSignedDriver.|Aucune.
computer.admins|ComputerQuick|Membres du groupe Administrateurs du poste.|Win32_Group et Win32_GroupUser.|Aucune.
computer.sessions|ComputerQuick|Comptes locaux et sessions du poste.|Win32_UserAccount.|Aucune.
computer.autostart|ComputerQuick|Programmes lancés au démarrage.|Win32_StartupCommand.|Aucune.
computer.shares|ComputerQuick|Dossiers partagés par le poste.|Win32_Share.|Aucune.
computer.printers|ComputerQuick|Imprimantes installées.|Win32_Printer.|Aucune.
computer.display|ComputerQuick|Carte graphique et résolution.|Win32_VideoController.|Aucune.
computer.physicaldisk|ComputerQuick|Modèle et interface du disque.|Win32_DiskDrive.|Aucune.
computer.certificates|ComputerDeep|Certificats du magasin Personnel de lʼordinateur : expirés, expirant dans les 30 jours, valides.|Registre SystemCertificates\MY, lu par lʼinventaire complet ; la clé privée nʼest jamais lue.|Autres magasins ; une lecture partielle nʼest jamais montrée comme un bon état.
computer.hotfix|ComputerQuick|Ancienneté du dernier correctif installé.|Win32_QuickFixEngineering.|Mises à jour que QFE nʼexpose pas.
software.count|Software|Nombre de logiciels et dʼéditeurs de la liste.|Registre Uninstall du poste, lu sur demande.|Logiciels non déclarés dans le registre.
software.size|Software|Somme des tailles déclarées.|Tailles déclarées dans le registre Uninstall.|Logiciels sans taille déclarée.
software.recent|Software|Logiciels installés ces 30 derniers jours.|Date dʼinstallation déclarée par le logiciel.|Logiciels sans date déclarée.
software.multiversion|Software|Logiciels présents en plusieurs versions.|Nom et version de la liste.|Aucune.
software.duplicates|Software|Logiciels de même nom et même version installés plus dʼune fois.|Nom, version, architecture, portée et profil de la liste.|Aucune : chaque occurrence reste une entrée de désinstallation distincte, rien nʼest fusionné.
software.nopublisher|Software|Logiciels sans éditeur déclaré.|Éditeur de la liste.|Aucune.
software.runtime|Software|Composants dʼexécution déclarés : Visual C++, .NET et WebView2.|Noms de la liste.|Aucune.
software.browsers|Software|Navigateurs détectés et leur version.|Noms et versions de la liste.|Aucune.
software.publishers|Software|Répartition par éditeur.|Éditeur de la liste.|Aucune.
software.architecture|Software|Répartition 32 et 64 bits.|Branche du registre lue.|Aucune.
software.scope|Software|Répartition entre installation machine et utilisateur.|Ruche du registre lue.|Aucune.
software.largest|Software|Logiciels les plus volumineux, en Mo.|Tailles déclarées dans le registre Uninstall.|Logiciels sans taille déclarée.
'@
$script:DomeniaWidgetSourceCache = $null

function Get-DomeniaWidgetSourceTable {
    # Parsed once: key -> {Key; Source; Formula; Criteria; Exclusions}. The text is immutable delivered data.
    $cache = $script:DomeniaWidgetSourceCache
    if (($null -ne $cache) -and ([string]$cache.Text -ceq [string]$script:DomeniaWidgetSourceText)) { return $cache.Index }
    $index = @{}
    foreach ($line in ([string]$script:DomeniaWidgetSourceText -split "`n")) {
        $text = $line.Trim()
        if (-not $text) { continue }
        $cells = @($text -split '\|')
        if ($cells.Count -ne 5) { continue }
        $index[[string]$cells[0]] = [pscustomobject]@{ Key = [string]$cells[0]; Source = [string]$cells[1]; Formula = [string]$cells[2]; Criteria = [string]$cells[3]; Exclusions = [string]$cells[4] }
    }
    $script:DomeniaWidgetSourceCache = [pscustomobject]@{ Text = [string]$script:DomeniaWidgetSourceText; Index = $index }
    return $index
}
function Get-DomeniaWidgetSource {
    # Source row of a built-in widget, or $null for a key the table does not know.
    param([string]$Key)
    $index = Get-DomeniaWidgetSourceTable
    if ($index.ContainsKey($Key)) { return $index[$Key] }
    return $null
}
function Get-DomeniaProbeWidgetSource {
    # Formula, criteria and exclusions of a probe widget, from its catalog entry: the class, namespace and properties
    # read, and the documented limitations of that projection (e.g. a zero cycle count is unknown, an undocumented
    # code is an estimate), so the explanation never says more than the probe can. $null for an unknown probe.
    param($Probe,[ValidateSet('Computer','Fleet','Software')][string]$Board = 'Computer')
    if ($null -eq $Probe) { return $null }
    $name = [string](Get-DomeniaMember $Probe 'Name' '')
    $namespace = [string](Get-DomeniaMember $Probe 'Namespace' '')
    $formula = if ($Board -eq 'Fleet') { 'Répartition des postes analysés selon la valeur relevée par « ' + $name + ' ».' } else { 'Valeur relevée par « ' + $name + ' » sur ce poste.' }
    $criteria = 'Requête WMI en lecture seule : classe ' + [string](Get-DomeniaMember $Probe 'Class' '') + $(if ($namespace) { ' (' + $namespace + ')' } else { '' }) + ', propriété(s) ' + (@(Get-DomeniaMember $Probe 'Properties' @()) -join ', ') + '.'
    $exclusions = 'Postes sans relevé exploitable (non lu, en erreur ou expiré) ; comptes désactivés.'
    $limits = ([string](Get-DomeniaMember $Probe 'Limitations' '')).Trim()
    if ($limits) { $exclusions += ' Limites documentées : ' + $limits }
    return [pscustomobject]@{ Formula = $formula; Criteria = $criteria; Exclusions = $exclusions }
}
function Get-DomeniaWidgetFieldNeeds {
    # Fields of a saved query to what a collection reads, by the family of the collection planner shared with the
    # workshop (Get-DomeniaCollectionFieldFamily): a probe or instance field is a WMI query of the catalog, inventory
    # fields come from the light WMI reading, presence from the ping, user from the console read; detail fields name
    # the saved WMI read of the recipe itself (detail:<RequestKey>:exists|count), keyed by the 64-hex RequestKey of
    # the recorded definition; every other field comes from the AD copy of the local base. A detail field whose key
    # is not such a RequestKey stays Workshop and is reported in DetailBroken: nothing is ever guessed from it.
    param([string[]]$Fields = @())
    $probes = New-Object System.Collections.Generic.List[string]
    $details = New-Object System.Collections.Generic.List[string]
    $ping = $false; $console = $false; $inventory = $false; $directory = $false; $workshop = $false; $detailBroken = $false
    foreach ($field in @($Fields)) {
        $name = [string]$field
        if (-not $name) { continue }
        switch (Get-DomeniaCollectionFieldFamily $name) {
            'Probe' {
                $id = if ($name -like 'probe:*') { $name.Substring(6) } else { [string]($name.Split(':'))[1] }
                if ($id -and (-not $probes.Contains($id))) { $probes.Add($id) }
            }
            'Inventory' { $inventory = $true }
            'Presence' { $ping = $true }
            'Console' { $console = $true }
            'Detail' {
                $workshop = $true
                $at = [string](Get-DomeniaQueryTimestampKey $name)
                $requestKey = if ($at.StartsWith('_at:detail:', [StringComparison]::Ordinal)) { $at.Substring(11) } else { '' }
                if ($requestKey -cmatch '^[0-9a-f]{64}$') { if (-not $details.Contains($requestKey)) { $details.Add($requestKey) } } else { $detailBroken = $true }
            }
            default { $directory = $true }
        }
    }
    return [pscustomobject]@{ ProbeIds = @($probes | Sort-Object); Ping = $ping; Console = $console; Inventory = $inventory; Directory = $directory; Workshop = $workshop; DetailKeys = @($details | Sort-Object); DetailBroken = $detailBroken }
}
function Get-DomeniaWidgetCollectionNeed {
    # What refreshing one widget alone reads, for the population of its board only. Kind:
    #   Remote            endpoint read through the pinned LiveConsole worker: ping, console, light inventory, probes
    #   ComputerInventory inventory of the selected workstation (Deep: the complete one)
    #   Directory         objects of the OU shown on Accueil reread into the local base (no ping, no WMI)
    #   Card              the selected object reread from AD
    #   BitLocker         presence of the BitLocker recovery objects of the OU (never a key)
    #   Software          software list of the selected workstation
    #   WmiDetail         the saved WMI read of the widget's own saved query (detail:* fields), validated against
    #                     the definition recorded with the recipe — never an arbitrary WQL string
    #   Local             computed from data already stored: nothing to collect
    #   Unknown           a widget whose source is not known: nothing is started
    # -Fields: requested fields of the saved query of a Query widget (Get-DomeniaQueryRequestedFields).
    # -RecipeMissing: the saved query of a Query widget is absent or ambiguous; nothing is started for it.
    # -Recipe: the saved query object (Get-DomeniaWidgetRecipe). Its recorded ReadDefinition is the only source of a
    # detail:* collection: a detail key the definition does not carry, a definition failing its own check, or no
    # definition at all is refused (DetailBlocked names why) and never collected from a guessed query.
    param([ValidateSet('Computer','Fleet','Software')][string]$Board,$Item,[string[]]$Fields = @(),[switch]$RecipeMissing,$Recipe = $null)
    $source = [string](Get-DomeniaMember $Item 'Source' '')
    $key = [string](Get-DomeniaMember $Item 'Key' '')
    $need = [ordered]@{ Board = $Board; Id = [string](Get-DomeniaMember $Item 'Id' ''); Source = $source; Key = $key; Kind = 'Unknown'; Ping = $false; Console = $false; Inventory = $false; Deep = $false; ProbeIds = @(); Workshop = $false; DetailKeys = @(); DetailBlocked = ''; Directory = $false; Label = '' }
    if ($source -eq 'Probe') {
        if ($Board -ne 'Software') { $need.Kind = 'Remote'; $need.ProbeIds = @($key) }
    } elseif (($source -eq 'Query') -and (-not $RecipeMissing)) {
        $parts = Get-DomeniaWidgetFieldNeeds -Fields $Fields
        $need.ProbeIds = @($parts.ProbeIds); $need.Ping = [bool]$parts.Ping; $need.Console = [bool]$parts.Console; $need.Inventory = [bool]$parts.Inventory; $need.Workshop = [bool]$parts.Workshop; $need.Directory = [bool]$parts.Directory
        $blocked = New-Object System.Collections.Generic.List[string]
        if ($parts.DetailBroken) { $blocked.Add('clé de relevé WMI invalide') }
        if (@($parts.DetailKeys).Count -gt 0) {
            $definition = Get-DomeniaMemberValue $Recipe 'ReadDefinition'
            if ($null -eq $definition) { $blocked.Add('aucune lecture WMI mémorisée dans la requête enregistrée') }
            else {
                $incoherent = $false
                try { Assert-DomeniaQueryReadDefinition $definition } catch { $incoherent = $true }
                if ($incoherent) { $blocked.Add('lecture WMI mémorisée incohérente avec son empreinte') }
                else {
                    $requestKey = [string](Get-DomeniaMember $definition 'RequestKey' '')
                    foreach ($detailKey in @($parts.DetailKeys)) { if ($detailKey -cne $requestKey) { $blocked.Add('relevé demandé absent de la lecture WMI mémorisée'); break } }
                }
            }
            if (-not $blocked.Count) { $need.DetailKeys = @($parts.DetailKeys) }
        }
        $need.DetailBlocked = ($blocked -join ' ; ')
        if ((@($need.ProbeIds).Count -gt 0) -or ($need.Ping) -or ($need.Console) -or ($need.Inventory)) { $need.Kind = 'Remote' }
        elseif ((-not $blocked.Count) -and (@($parts.DetailKeys).Count -gt 0)) { $need.Kind = 'WmiDetail' }
        elseif ($parts.Directory) { $need.Kind = $(if ($Board -eq 'Computer') { 'Card' } else { 'Directory' }) }
        elseif (-not $parts.Workshop) { $need.Kind = 'Local' }
    } elseif ($source -eq 'Builtin') {
        $row = Get-DomeniaWidgetSource -Key $key
        $kind = if ($null -ne $row) { [string]$row.Source } else { '' }
        switch ($kind) {
            'Presence' { $need.Kind = 'Remote'; $need.Ping = $true }
            'Console' { $need.Kind = 'Remote'; $need.Console = $true }
            'Inventory' { $need.Kind = 'Remote'; $need.Inventory = $true }
            'ComputerQuick' { $need.Kind = 'ComputerInventory' }
            'ComputerDeep' { $need.Kind = 'ComputerInventory'; $need.Deep = $true }
            'Directory' { $need.Kind = 'Directory' }
            'Card' { $need.Kind = 'Card' }
            'BitLocker' { $need.Kind = 'BitLocker' }
            'Software' { $need.Kind = 'Software' }
            'Local' { $need.Kind = 'Local' }
        }
        # fleet.reach combines the dated ping and the dated WMI answer of the observation: refreshing it alone
        # rereads both, so the reach distribution never mixes a fresh ping with a stale WMI answer.
        if ($key -eq 'fleet.reach') { $need.Inventory = $true }
    }
    $need.Label = Get-DomeniaWidgetNeedText -Need ([pscustomobject]$need)
    return [pscustomobject]$need
}
function Get-DomeniaWidgetNeedText {
    # What the refresh of this widget reads, in plain words, with its population. A widget mixing sources names every
    # source it reads: a saved WMI read carried beside another source is announced, never silently dropped.
    param($Need)
    $board = [string](Get-DomeniaMember $Need 'Board' '')
    $population = if ($board -eq 'Fleet') { 'les postes actifs de lʼOU affichée' } else { 'le poste sélectionné' }
    $detailKeys = @(Get-DomeniaMember $Need 'DetailKeys' @())
    $detailBlocked = [string](Get-DomeniaMember $Need 'DetailBlocked' '')
    $detailText = ''
    if ($detailKeys.Count) { $detailText = ' La requête WMI mémorisée de ce widget est aussi relue.' }
    elseif ($detailBlocked) { $detailText = ' Un relevé WMI personnalisé est refusé : ' + $detailBlocked + ' ; corrigez la requête enregistrée.' }
    switch ([string](Get-DomeniaMember $Need 'Kind' '')) {
        'Remote' {
            $parts = New-Object System.Collections.Generic.List[string]
            if ([bool](Get-DomeniaMember $Need 'Ping' $false)) { $parts.Add('ping') }
            if ([bool](Get-DomeniaMember $Need 'Console' $false)) { $parts.Add('utilisateur console (WMI)') }
            if ([bool](Get-DomeniaMember $Need 'Inventory' $false)) { $parts.Add('relevé WMI léger') }
            $probes = @(Get-DomeniaMember $Need 'ProbeIds' @()).Count
            if ($probes) { $parts.Add([string]$probes + ' requête(s) WMI de ce widget') }
            $text = 'Relit seulement : ' + ($parts -join ', ') + ', pour ' + $population + ', en lecture seule.'
            if ([bool](Get-DomeniaMember $Need 'Directory' $false)) { $text += ' Les attributs AD de lʼOU sont aussi relus lors de lʼactualisation du widget du parc.' }
            $text += $detailText
            return $text
        }
        'WmiDetail' {
            $text = 'Relit seulement : la requête WMI mémorisée de ce widget, pour ' + $population + ', en lecture seule.'
            if ([bool](Get-DomeniaMember $Need 'Directory' $false)) {
                if ($board -eq 'Computer') { $text += ' La fiche du poste sélectionné est aussi relue depuis lʼannuaire.' }
                else { $text += ' Les attributs AD de lʼOU sont aussi relus lors de lʼactualisation du widget du parc.' }
            }
            return $text
        }
        'ComputerInventory' { if ([bool](Get-DomeniaMember $Need 'Deep' $false)) { return 'Inventaire complet du poste sélectionné (environ 3 minutes), en lecture seule.' }; return 'Inventaire rapide du poste sélectionné (environ 1 minute), en lecture seule.' }
        'Directory' { return 'Relit les objets AD de lʼOU affichée et de ses sous-OU dans la base locale ; aucun ping ni WMI.' + $detailText }
        'Card' { return 'Relit la fiche du poste sélectionné depuis lʼannuaire.' + $detailText }
        'BitLocker' { return 'Lit la présence des clés BitLocker de lʼOU affichée : nom, emplacement et date, jamais la clé.' }
        'Software' { return 'Recharge la liste des logiciels du poste sélectionné.' }
        'Local' {
            if($board -eq 'Computer'){return 'Relit lʼinventaire du poste puis recalcule cette synthèse.'}
            if([string]$Need.Key -in @('fleet.trend.win10','fleet.trend.stale')){return 'Relit les données AD de lʼOU et recalcule le point actuel de la tendance.'}
            if([string]$Need.Key -eq 'fleet.trend.lowdisk'){return 'Relit lʼinventaire WMI de lʼOU et recalcule le point actuel de la tendance.'}
            if($board -eq 'Fleet'){return 'Relit AD, ping et inventaire WMI de lʼOU, puis recalcule cette synthèse. Les points historiques sont conservés.'}
            return 'Recalcule depuis les données enregistrées, sans collecte.'
        }
    }
    if ([bool](Get-DomeniaMember $Need 'Workshop' $false)) { return 'Relevés WMI personnalisés refusés : ' + $(if ($detailBlocked) { $detailBlocked } else { 'aucune lecture WMI mémorisée exploitable' }) + '. Aucune collecte nʼest lancée pour ce widget.' }
    return 'Source inconnue : aucune collecte nʼest lancée pour ce widget.'
}
function Get-DomeniaWidgetPauseText {
    # What pausing this widget changes, without promising a saving that does not exist: a reading shared by other
    # widgets (inventory of the workstation, AD copy, ping and light WMI used by the health) stays as it is.
    param($Need)
    $kind = [string](Get-DomeniaMember $Need 'Kind' '')
    if ($kind -eq 'Remote') {
        $probes = @(Get-DomeniaMember $Need 'ProbeIds' @()).Count
        $shared = New-Object System.Collections.Generic.List[string]
        if ([bool](Get-DomeniaMember $Need 'Ping' $false)) { $shared.Add('ping') }
        if ([bool](Get-DomeniaMember $Need 'Console' $false)) { $shared.Add('console') }
        if ([bool](Get-DomeniaMember $Need 'Inventory' $false)) { $shared.Add('WMI léger') }
        $text = 'Mesure suspendue'
        if ($probes) { $text += ' : aucune requête WMI nʼest lancée pour ce widget' }
        $why = if ([string](Get-DomeniaMember $Need 'Board' '') -eq 'Fleet') { ') reste lu par les actions de liste, car la santé du parc lʼutilise.' } else { ') reste lu par les autres actions du poste.' }
        if ($shared.Count) { $text += $(if ($probes) { '. ' } else { ' : ce widget nʼest plus actualisé. ' }) + 'Le relevé commun (' + ($shared -join ', ') + $why }
        else { $text += '.' }
        return $text
    }
    switch ($kind) {
        'ComputerInventory' { return 'Widget suspendu : il nʼest plus calculé. Lʼinventaire du poste reste une lecture commune à tous ses widgets.' }
        'Directory' { return 'Widget suspendu : il nʼest plus calculé ni actualisé ; la base locale reste mise à jour par lʼOU.' }
        'Card' { return 'Widget suspendu : il nʼest plus calculé ; la fiche du poste reste lue à son ouverture.' }
        'BitLocker' { return 'Mesure suspendue : la présence des clés BitLocker nʼest plus lue pour ce widget.' }
        'Software' { return 'Widget suspendu : il nʼest plus calculé ; la liste des logiciels reste commune.' }
        'WmiDetail' { return 'Mesure suspendue : la requête WMI mémorisée de ce widget nʼest plus relancée.' }
    }
    return 'Widget suspendu : il nʼest plus calculé.'
}
function Get-DomeniaWidgetCollectAdmission {
    # Admission of the endpoint reads of one widget, counted on the workstations left to read. The widget ceiling
    # (Collection.WidgetMaxTargets through Test-DomeniaParkTargetAdmission, none by default) applies to every widget collection:
    # above it nothing is read and Reason says why. Adding a widget is the explicit gesture (decision David
    # 2026-10-14): Direct, its collection starts without the confirmation for at most Limit workstations; more asks
    # the inline confirmation with its count first. Refresh and resume always ask it (Direct is only read for an
    # added widget). Limit: 200 workstations by default, bounded 1 to 2000 and never above the ceiling.
    # Maximum 0 or less: no ceiling for widgets (decision David 2026-10-19, setting « Plafond des widgets » of
    # Réglages de collecte); the count is still confirmed above Limit.
    param([int]$TargetCount,[int]$Limit = 200,[int]$Maximum = 500)
    $count = [Math]::Max(0, $TargetCount)
    if ($Maximum -le 0) {
        $bounded = [Math]::Max(1, [Math]::Min(2000, $Limit))
        $reason = ''
        if ($count -le 0) { $reason = 'Aucun poste à lire pour ce widget.' }
        return [pscustomobject]@{ Allowed = ($count -gt 0); Direct = (($count -gt 0) -and ($count -le $bounded)); Limit = $bounded; Maximum = 0; Count = $count; Reason = $reason }
    }
    $ceiling = Test-DomeniaParkTargetAdmission -Count $count -Maximum $Maximum
    $bounded = [Math]::Max(1, [Math]::Min([Math]::Min(2000, $Limit), [int]$ceiling.Maximum))
    $reason = ''
    if (-not [bool]$ceiling.Allowed) {
        if ([string]$ceiling.Code -eq 'Ceiling') { $reason = [string]$count + ' postes à lire pour ce widget : plafond ' + [string]$ceiling.Maximum + ' (réglage « Plafond des widgets » dans Atelier > Réglages de collecte).' }
        else { $reason = 'Aucun poste à lire pour ce widget.' }
    }
    return [pscustomobject]@{ Allowed = [bool]$ceiling.Allowed; Direct = (([bool]$ceiling.Allowed) -and ($count -le $bounded)); Limit = $bounded; Maximum = [int]$ceiling.Maximum; Count = $count; Reason = $reason }
}
function Get-DomeniaWidgetCollectSlot {
    # FI-18: the endpoint reads of a widget run in the survey scope of its population: the workstation open in Poste
    # (workstation and software boards) in 'Computer', the OU shown on Accueil in 'List' with the perimeter surveys
    # of the boards. A survey of one scope never waits for the other.
    param([string]$Board)
    if ($Board -eq 'Fleet') { return 'List' }
    return 'Computer'
}
function Format-DomeniaWidgetCollectProgress {
    # Progress line of a widget whose data is being collected; the figure stays the last one actually read.
    # Planning: the run checks the stored measurements of each workstation before any network read (Done of Total
    # checked, Fresh already answered). Waiting: queued behind the recalculation of the OU that the previous run
    # started; the collection context is refused until the new snapshot is drawn.
    param([ValidateSet('Queued','Waiting','Preparing','Planning','Confirming','Running','Inventory','Directory','BitLocker','Card','Software','Local','WmiDetail')][string]$Phase,[int]$Done = 0,[int]$Total = 0,[int]$Fresh = 0,[int]$Failed = 0)
    switch ($Phase) {
        'Queued' { return 'En file : démarre après le relevé en cours.' }
        'Waiting' { return 'En file : en attente du recalcul de lʼOU.' }
        'Preparing' { return 'Préparation de la collecte…' }
        'Planning' {
            $text = 'Recherche des mesures manquantes · ' + [string]$Done + '/' + [string]$Total + ' poste(s)'
            if ($Fresh -gt 0) { $text += ' · ' + [string]$Fresh + ' déjà à jour' }
            return $text
        }
        'Confirming' { return ('Collecte en attente de confirmation · ' + [string]$Total + ' poste(s)') }
        'Running' {
            $text = 'Collecte en cours · ' + [string]$Done + '/' + [string]$Total + ' poste(s)'
            if ($Fresh -gt 0) { $text += ' · ' + [string]$Fresh + ' déjà à jour' }
            if ($Failed -gt 0) { $text += ' · ' + [string]$Failed + ' non confirmé(s)' }
            return $text
        }
        'Inventory' { return 'Inventaire du poste en cours…' }
        'Directory' { return 'Lecture AD de lʼOU en cours…' }
        'BitLocker' { return 'Lecture des clés BitLocker de lʼOU en cours…' }
        'Card' { return 'Relecture de la fiche en cours…' }
        'Software' { return 'Lecture des logiciels en cours…' }
        'Local' { return 'Recalcul local en cours…' }
        'WmiDetail' { return 'Relecture de la requête WMI mémorisée…' }
    }
    return ''
}
function Get-DomeniaWidgetPlaceholder {
    # Card of a widget that has no figure (decision David 2026-10-14, replaces Non lu par cet inventaire): paused,
    # being collected or queued, read by the complete inventory only, absent from the last reading, or not collected
    # yet, with the button that acts on it. Never a measure. Action: Resume, Refresh or '' (nothing to offer).
    param($Need,[bool]$Paused = $false,[string]$Progress = '',[bool]$Collected = $false,[bool]$DeepRead = $false,[string]$CollectedAt = '')
    $kind = [string](Get-DomeniaMember $Need 'Kind' '')
    if ($Paused) { return [pscustomobject]@{ State = 'Paused'; Message = (Get-DomeniaWidgetPauseText -Need $Need); Action = 'Resume'; ActionText = 'Reprendre la mesure'; Glyph = [string][char]0xE769 } }
    if ($Progress) { return [pscustomobject]@{ State = 'Collecting'; Message = $Progress; Action = ''; ActionText = ''; Glyph = [string][char]0xE895 } }
    if (($kind -eq 'ComputerInventory') -and ($Collected) -and ([bool](Get-DomeniaMember $Need 'Deep' $false)) -and (-not $DeepRead)) {
        return [pscustomobject]@{ State = 'Deep'; Message = 'Lu par lʼinventaire complet seulement : le dernier inventaire était rapide.'; Action = 'Refresh'; ActionText = 'Inventaire complet'; Glyph = [string][char]0xE9D2 }
    }
    if ($kind -eq 'Unknown') { return [pscustomobject]@{ State = 'Unknown'; Message = (Get-DomeniaWidgetNeedText -Need $Need); Action = ''; ActionText = ''; Glyph = [string][char]0xE9CE } }
    if ($Collected) {
        $when = if ($CollectedAt) { ' du ' + $CollectedAt } else { '' }
        $board = [string](Get-DomeniaMember $Need 'Board' '')
        $message = if ($board -eq 'Fleet') { 'Aucune valeur dans le dernier calcul' + $when + ' pour ce périmètre.' } elseif ($board -eq 'Software') { 'Aucune valeur dans la dernière liste' + $when + '.' } else { 'Absent du dernier relevé' + $when + ' : information non renvoyée pour ce poste.' }
        return [pscustomobject]@{ State = 'Absent'; Message = $message; Action = 'Refresh'; ActionText = $(if ($board -eq 'Fleet') { 'Actualiser' } else { 'Relire' }); Glyph = [string][char]0xE9D2 }
    }
    if ($kind -eq 'Local') { return [pscustomobject]@{ State = 'Missing'; Message = 'Pas encore calculé.'; Action = 'Refresh'; ActionText = 'Recalculer'; Glyph = [string][char]0xE9D2 } }
    return [pscustomobject]@{ State = 'Missing'; Message = 'Pas encore collecté pour ce tableau.'; Action = 'Refresh'; ActionText = 'Collecter'; Glyph = [string][char]0xE9D2 }
}
function Test-DomeniaComputerInventoryDeep {
    # The inventory result carries no mode: the categories read only by the complete inventory reveal it.
    param($Result)
    foreach ($row in @(Get-DomeniaMember $Result 'Rows' @())) {
        if ([string](Get-DomeniaMember $row 'Category' '') -in @('Processus','Evenements systeme','Taches planifiees','Certificats machine')) { return $true }
    }
    return $false
}
function Format-DomeniaWidgetDetailLabel {
    # Name of the exact selection opened from a widget (point 73): its title, the count it showed and the
    # calculation it comes from, so the list reads as that snapshot. Kept under 110 characters (recipe names: 120).
    param([string]$Title,[int]$Count,$ComputedAtUtc = $null)
    $when = ''
    if ($ComputedAtUtc -is [datetime]) { $when = ' · calcul du ' + $ComputedAtUtc.ToLocalTime().ToString('dd/MM HH:mm', [Globalization.CultureInfo]::InvariantCulture) }
    $suffix = ' · ' + [string]$Count + ' poste' + $(if ($Count -gt 1) { 's' } else { '' }) + $when
    $head = ([string]$Title).Trim()
    if (($head.Length + $suffix.Length) -gt 110) { $head = $head.Substring(0, [Math]::Min($head.Length, [Math]::Max(10, 109 - $suffix.Length))) + [string][char]0x2026 }
    return $head + $suffix
}
function Test-DomeniaWidgetSnapshotCurrent {
    # A widget opens its exact list only from the calculation it was drawn from (point 73): a newer calculation
    # may count other workstations under the same title.
    param([string]$Drawn,[string]$Current)
    return (([bool]$Drawn) -and ($Drawn -ceq $Current))
}
function Get-DomeniaWidgetExplanation {
    # Point 6: what one figure means, from the data the board already holds; nothing is read to explain it.
    # Rows {Aspect; Text}: displayed value, formula, perimeter, criteria, exclusions, coverage, dates, workstations
    # of the total and what refreshing this widget reads. -Members says what Afficher les postes opens: Exact (the
    # GUID list kept with the calculation, TargetCount workstations), Recomputed (no list is kept: it is evaluated
    # again from the snapshot shown when the button is used), Selected (the selected workstation, no list button) or
    # None. Without -Members: Exact when TargetCount is known, otherwise None.
    param(
        [string]$Board,
        $Item,
        [string]$Title = '',
        $Entry = $null,
        $Need = $null,
        [string]$Scope = '',
        [string]$Coverage = '',
        $ComputedAtUtc = $null,
        [int]$TargetCount = -1,
        [ValidateSet('','Exact','Recomputed','Selected','None')][string]$Members = '',
        [string]$Formula = '',
        [string]$Criteria = '',
        [string]$Exclusions = '',
        [int]$MaxAgeDays = 30
    )
    $key = [string](Get-DomeniaMember $Item 'Key' '')
    $source = [string](Get-DomeniaMember $Item 'Source' '')
    $row = if ($source -eq 'Builtin') { Get-DomeniaWidgetSource -Key $key } else { $null }
    if ((-not $Formula) -and ($null -ne $row)) { $Formula = [string]$row.Formula }
    if ((-not $Criteria) -and ($null -ne $row)) { $Criteria = [string]$row.Criteria }
    if ((-not $Exclusions) -and ($null -ne $row)) { $Exclusions = [string]$row.Exclusions }
    if (-not $Formula) { $Formula = 'Formule non documentée pour ce widget.' }
    if (-not $Criteria) { $Criteria = 'Non documentés pour ce widget.' }
    if (-not $Exclusions) { $Exclusions = 'Non documentées pour ce widget.' }
    $kind = [string](Get-DomeniaMember $Need 'Kind' '')
    if ($kind -in @('Remote','WmiDetail')) { $Exclusions += ' Relevés de plus de ' + [string]([Math]::Max(1, $MaxAgeDays)) + ' jours ignorés.' }
    $value = [string](Get-DomeniaMember $Entry 'Value' '')
    $detail = [string](Get-DomeniaMember $Entry 'Detail' '')
    $shown = if ($null -eq $Entry) { 'Aucune valeur : ce widget nʼa pas encore de donnée.' } elseif (($value) -and ($detail)) { $value + ' · ' + $detail } elseif ($value) { $value } elseif ($detail) { $detail } else { 'Valeur vide.' }
    $dates = if ($ComputedAtUtc -is [datetime]) { 'Calcul local du ' + $ComputedAtUtc.ToLocalTime().ToString('dd/MM/yyyy HH:mm', [Globalization.CultureInfo]::InvariantCulture) + '.' } else { 'Date de calcul non conservée.' }
    if ($kind -in @('Remote','WmiDetail','ComputerInventory','Directory','Card','BitLocker','Software')) { $dates += ' Chaque mesure garde la date de sa collecte ; un recalcul ne la rajeunit pas.' }
    # $listMode, never $members: PowerShell names ignore case and -Members is a validated parameter.
    $listMode = if ($Members) { $Members } elseif ($TargetCount -ge 0) { 'Exact' } else { 'None' }
    if (($listMode -eq 'Exact') -and ($TargetCount -lt 0)) { $listMode = 'None' }
    $memberText = switch ($listMode) {
        'Exact' { [string]$TargetCount + ' poste(s) : liste exacte des GUID conservée avec ce calcul, ouverte par Afficher les postes.' }
        'Recomputed' { 'Aucune liste figée nʼest conservée pour ce chiffre : Afficher les postes la recalcule depuis le calcul affiché, sans nouvelle lecture.' }
        'Selected' { 'Le poste sélectionné seulement.' }
        default { 'Liste nominative non conservée pour ce chiffre.' }
    }
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($pair in @(
        @('Valeur affichée', $shown),
        @('Formule', $Formula),
        @('Périmètre', $(if ($Scope) { $Scope } else { 'Non précisé.' })),
        @('Critères', $Criteria),
        @('Exclusions', $Exclusions),
        @('Couverture', $(if ($Coverage) { $Coverage } else { 'Non mesurée pour ce chiffre.' })),
        @('Dates', $dates),
        @('Postes du total', $memberText),
        @('Actualiser ce widget', $(if ($null -ne $Need) { [string](Get-DomeniaMember $Need 'Label' '') } else { 'Non disponible.' }))
    )) { $rows.Add([pscustomobject]@{ Aspect = [string]$pair[0]; Text = [string]$pair[1] }) }
    return [pscustomobject]@{ Title = $(if ($Title) { $Title } else { $key }); Board = $Board; Key = $key; TargetCount = $TargetCount; Members = $listMode; Rows = $rows.ToArray() }
}

function Get-DomeniaWidgetSourceFamilies {
    # Source families of the displayed information, not the time its chart was drawn.
    param($Need)
    $detailCarried = (@(Get-DomeniaMember $Need 'DetailKeys' @()).Count -gt 0)
    switch ([string]$Need.Kind) {
        'Directory' { if ($detailCarried) { return @('AD','WmiDetail') }; return 'AD' }
        'Card' { if ($detailCarried) { return @('AD','WmiDetail') }; return 'AD' }
        'BitLocker' { return 'BitLocker' }
        'Software' { return 'Software' }
        'ComputerInventory' { return 'ComputerInventory' }
        'WmiDetail' { if ($Need.Directory) { return @('AD','WmiDetail') }; return 'WmiDetail' }
        'Remote' {
            if ($Need.Directory) { 'AD' }
            if ($Need.Ping) { 'Ping' }
            if ($Need.Console) { 'Console' }
            if ($Need.Inventory) { 'Inventory' }
            if (@($Need.ProbeIds).Count) { 'Probe' }
            if ($detailCarried) { 'WmiDetail' }
            return
        }
        'Local' {
            switch -Wildcard ([string]$Need.Key) {
                'fleet.trend.win10' { return 'AD' }
                'fleet.trend.stale' { return 'AD' }
                'fleet.trend.lowdisk' { return 'Inventory' }
                'fleet.*' { return @('AD','Ping','Inventory') }
                'computer.*' { return @('AD','ComputerInventory') }
            }
        }
    }
    return 'Unknown'
}
function Format-DomeniaWidgetDataDates {
    # Successful source clocks only. A failed attempt or a local redraw never rejuvenates the footer.
    param([object[]]$Rows=@(),[datetime]$NowUtc=[datetime]::UtcNow)
    $lines=New-Object System.Collections.Generic.List[string]
    foreach ($row in $Rows) {
        $source=[string](Get-DomeniaMember $row 'Source' 'Source inconnue')
        $oldest=ConvertTo-DomeniaUtcDate (Get-DomeniaMemberValue $row 'OldestUtc')
        $newest=ConvertTo-DomeniaUtcDate (Get-DomeniaMemberValue $row 'NewestUtc')
        if ($null -ne $oldest -and $oldest -gt $NowUtc) { $oldest=$null }
        if ($null -ne $newest -and $newest -gt $NowUtc) { $newest=$null }
        $text=$source+' · '
        if ($null -eq $oldest -or $null -eq $newest) { $text+='non daté' }
        else {
            $text+=$oldest.ToLocalTime().ToString('dd/MM/yyyy HH:mm',[Globalization.CultureInfo]::InvariantCulture)
            if ($newest -ne $oldest) { $text+=' → '+$newest.ToLocalTime().ToString('dd/MM/yyyy HH:mm',[Globalization.CultureInfo]::InvariantCulture) }
        }
        $missing=[int](Get-DomeniaMember $row 'Missing' 0)
        if ($missing -gt 0) { $text+=' · '+$missing+' non lu(s)' }
        $lines.Add($text)
    }
    if (-not $lines.Count) { $lines.Add('Source inconnue · non daté') }
    $text=$lines.ToArray() -join "`n"
    return [pscustomobject]@{Text=$text;Detail=('Dates des données conservées, par source. Une tentative en échec ne les remplace pas.'+"`n"+$text)}
}
function Get-DomeniaWidgetDetailClocks {
    # Real commit clocks of the saved WMI reads (detail:* fields) among the DataSources rows the board already
    # holds (Measure-DomeniaQueryCoverage): oldest, newest and unread count over every saved-read clock. Rows
    # are matched by the label Get-DomeniaQueryTimestampSource gives to detail clocks; nothing is read here.
    # $null when no row carries a date: the footer then honestly says « non daté », never a fabricated date.
    param([object[]]$Rows = @(),[string[]]$DetailKeys = @())
    $keys = @($DetailKeys | Where-Object { [string]$_ -cmatch '^[0-9a-f]{64}$' })
    if (-not $keys.Count) { return $null }
    $label = [string](Get-DomeniaQueryTimestampSource ('_at:detail:' + [string]$keys[0])).Label
    if (-not $label) { return $null }
    $oldest = $null; $newest = $null; $missing = 0; $dated = $false
    foreach ($row in @($Rows)) {
        if ([string](Get-DomeniaMember $row 'Source' '') -cne $label) { continue }
        $o = ConvertTo-DomeniaUtcDate (Get-DomeniaMemberValue $row 'OldestUtc')
        $n = ConvertTo-DomeniaUtcDate (Get-DomeniaMemberValue $row 'NewestUtc')
        $missing += [int](Get-DomeniaMember $row 'Missing' 0)
        if ($null -ne $o) { $dated = $true; if (($null -eq $oldest) -or ($o -lt $oldest)) { $oldest = $o } }
        if ($null -ne $n) { $dated = $true; if (($null -eq $newest) -or ($n -gt $newest)) { $newest = $n } }
    }
    if (-not $dated) { return $null }
    return [pscustomobject]@{ OldestUtc = $oldest; NewestUtc = $newest; Missing = $missing }
}
