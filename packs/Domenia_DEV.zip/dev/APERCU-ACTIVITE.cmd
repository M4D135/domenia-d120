@echo off
setlocal
cd /d "%~dp0"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%PS%" -NoLogo -NoProfile -STA -File "%~dp0wad\tests\Test-DomeniaActivityLayout.ps1" -Preview
set "RESULT=%ERRORLEVEL%"
echo.
pause
exit /b %RESULT%
